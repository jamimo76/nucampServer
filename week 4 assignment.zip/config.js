module.exports = {
  secretKey: "12345-67890-09876-54321",
  mongoUrl: "mongodb://localhost:27017/nucampsite",
  facebook: {
    clientId: "361283745781902",
    clientSecret: "03f5ce978abd9641afc9337518739d7a"
  }
};
